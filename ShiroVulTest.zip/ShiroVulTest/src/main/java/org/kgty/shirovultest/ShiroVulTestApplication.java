package org.kgty.shirovultest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShiroVulTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShiroVulTestApplication.class, args);
    }

}
