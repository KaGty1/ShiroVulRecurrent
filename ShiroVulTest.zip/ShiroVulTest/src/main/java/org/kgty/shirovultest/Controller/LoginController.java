package org.kgty.shirovultest.Controller;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(String username, String password, Model model) {
        UsernamePasswordToken token = new UsernamePasswordToken(username, password);
        Subject subject = SecurityUtils.getSubject();
        try {
            subject.login(token);  // 登录验证
            return "redirect:/index";  // 登录成功跳转到index
        } catch (Exception e) {
            model.addAttribute("error", "Invalid username or password");
            return "login";  // 登录失败返回登录页
        }
    }

    @GetMapping("/index")
    public String indexPage() {
        return "index";  // 访问成功后跳转到主页
    }

    @GetMapping("/secret")
    public String secretPage() {
        return "secret";  // 需要权限的页面
    }

    @GetMapping("/admin/{name}")
    public String adminPage(@PathVariable String name) {
        return "admin";
    }
}
